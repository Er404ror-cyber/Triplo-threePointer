import { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import { Info, Phone, Menu, X } from "lucide-react";
import LanguageSwitcher from "../../context/buttom";
import { useTranslate } from "../../context/LanguageProvider";

export const Header = () => {
  const { t } = useTranslate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const headerRef = useRef<HTMLElement>(null);

  const NAV_LINKS = [
    {
      label: "home",
      to: "/",
    },
    {
      label: "publications",
      to: "/publications",
    },
    {
      label: "PublicJogadores",
      to: "/PublicJogadores",
    },
    {
      label: "admin",
      to: "/admin/login",
    },
  ] as const;

  // Fecha o menu ao tocar/clicar fora do header
  useEffect(() => {
    if (!isMenuOpen) return;

    const handleClickOutside = (event: MouseEvent | TouchEvent) => {
      if (headerRef.current && !headerRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("touchstart", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("touchstart", handleClickOutside);
    };
  }, [isMenuOpen]);

  // Bloqueia o scroll da página enquanto o menu mobile estiver aberto
  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }

    return () => {
      document.body.style.overflow = "";
    };
  }, [isMenuOpen]);

  return (
    <>
      {/* 1. O HEADER VERDADEIRO */}
      <header
        ref={headerRef}
        className="absolute left-0 top-0 z-50 w-full border-b border-white/10 bg-black/90 shadow-lg"
      >
        <div className="mx-auto flex w-full max-w-7xl items-center justify-between px-6 py-4">

          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-white">
              <svg
                viewBox="0 0 100 100"
                className="h-6 w-6"
                aria-hidden="true"
              >
                {/* Corpo da bola laranja */}
                <circle cx="50" cy="50" r="48" fill="#ea580c" stroke="#000000" strokeWidth="4" />
                {/* Linha vertical central */}
                <line x1="50" y1="2" x2="50" y2="98" stroke="#000000" strokeWidth="4" />
                {/* Linha horizontal central */}
                <line x1="2" y1="50" x2="98" y2="50" stroke="#000000" strokeWidth="4" />
                {/* Costura curva esquerda */}
                <path
                  d="M 16 16 C 36 34 36 66 16 84"
                  fill="none"
                  stroke="#000000"
                  strokeWidth="4"
                />
                {/* Costura curva direita */}
                <path
                  d="M 84 16 C 64 34 64 66 84 84"
                  fill="none"
                  stroke="#000000"
                  strokeWidth="4"
                />
              </svg>
            </div>
            <span className="text-lg tracking-widest text-slate-300">
              T3P
            </span>
          </Link>

          {/* Nav desktop com animação da direita para a esquerda */}
          <nav className="hidden items-center gap-8 text-xs font-bold tracking-widest text-slate-300 md:flex">
            {NAV_LINKS.map((link) => (
 <Link
  key={link.to}
  to={link.to}
  className="relative pb-1 uppercase text-slate-300 transition-colors duration-300 hover:text-white
             after:absolute after:bottom-0 after:left-0 after:h-[2px] after:w-0 after:bg-white 
             after:transition-all after:duration-300 after:ease-out hover:after:w-full"
>
  {t(link.label)}
</Link>
))}
          </nav>

          <div className="flex items-center gap-6 text-slate-300">
            <div className="hidden items-center gap-6 md:flex ">
              <LanguageSwitcher />
              <Info size={16} className="cursor-pointer hover:text-white transition-colors" />
              <Phone size={16} className="cursor-pointer hover:text-white transition-colors" />
            </div>

            <button
              onClick={() => setIsMenuOpen((prev) => !prev)}
              aria-label={isMenuOpen ? "Fechar menu" : "Abrir menu"}
              aria-expanded={isMenuOpen}
              className="flex items-center justify-center rounded-full p-2 text-slate-300 hover:text-white md:hidden"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Menu mobile */}
        {isMenuOpen && (
          <nav className="absolute left-0 top-full w-full flex flex-col gap-2 border-b border-white/10 bg-black/95 px-6 py-5 shadow-xl md:hidden">
            {NAV_LINKS.map((link) => (
  <Link
  key={link.to}
  to={link.to}
  onClick={() => setIsMenuOpen(false)}
  className="relative pb-2 pt-2 text-sm font-bold uppercase tracking-widest text-slate-300 transition-colors duration-300 hover:text-white
             after:absolute after:bottom-0 after:left-0 after:h-[2px] after:w-0 after:bg-white 
             after:transition-all after:duration-300 after:ease-out hover:after:w-full"
>
  {t(link.label)}
</Link>
))}

            <div className="mt-3 flex items-center gap-4 border-t border-white/10 px-3 pt-5 text-slate-300">
              <LanguageSwitcher />
              <a href="#" className="flex items-center gap-2 py-2 hover:text-white transition-colors">
                <Info size={18} />
                <span className="text-sm font-bold uppercase tracking-widest">Info</span>
              </a>
              <a href="#" className="flex items-center gap-2 py-2 hover:text-white transition-colors">
                <Phone size={18} />
                <span className="text-sm font-bold uppercase tracking-widest">Contato</span>
              </a>
            </div>
          </nav>
        )}
      </header>

      {/* 2. O ESPAÇADOR FANTASMA */}
      <div className="h-[74px] w-full flex-shrink-0" aria-hidden="true"></div>
    </>
  );
};